import React, { useState } from 'react';
import { ScrollView, Text, View, Switch, Alert, TouchableOpacity, StyleSheet, Platform } from 'react-native';

const MyChoices = () => {
  const [selectedChoices, setSelectedChoices] = useState({});

  const toggleSwitch = (choice1, choice2) => {
    setSelectedChoices((prev) => ({
      ...prev,
      [choice1]: !prev[choice1],
      [choice2]: prev[choice1],
    }));
  };

  const carmodelslist = [
    ['McLaren 12C'],
    ['Nissan 240SX'],
    ['Toyota 86'],
    ['Lexus LFA'],
    ['Ferrari 458 Italia'],
    ['Bugatti EB110'],
  ];

  const handleSubmit = () => {
    const selected = Object.keys(selectedChoices).filter((key) => selectedChoices[key]);
    const message = selected.length > 0
      ? selected.map((choice, index) => `${index + 1}. ${choice}`).join('\n')
      : 'No items selected';
    Alert.alert('Your Choices', message);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Customize Your Dream Sports Car</Text>
      {carmodelslist.map(([choice1, choice2], index) => (
        <View key={index} style={styles.choiceContainer}>
          <Text style={styles.choiceText}>{choice1}</Text>
          <Switch
            value={selectedChoices[choice1] || false}
            onValueChange={() => toggleSwitch(choice1, choice2)}
            trackColor={{ false: '#d3d3d3', true: '#34d399' }}
            thumbColor={selectedChoices[choice1] ? '#22c55e' : '#f4f4f4'}
          />
          {choice2 && <Text style={styles.choiceText}>{choice2}</Text>}
        </View>
      ))}
      <TouchableOpacity onPress={handleSubmit} style={styles.submitButton}>
        <Text style={styles.submitButtonText}>Submit Choices</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: Platform.OS === 'ios' ? '#fdf6e4' : '#f9fafb',
  },
  header: {
    fontSize: 24,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 20,
    color: '#0f172a',
    textTransform: 'uppercase',
  },
  choiceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 5,
    elevation: 3,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  choiceText: {
    fontSize: 18,
    color: '#374151',
    fontWeight: '500',
  },
  submitButton: {
    backgroundColor: '#34d399',
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    shadowColor: '#059669',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 4,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
});

export default MyChoices;
